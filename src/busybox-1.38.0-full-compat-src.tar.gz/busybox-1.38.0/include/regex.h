#ifndef BB_COMPAT_REGEX_H
#define BB_COMPAT_REGEX_H 1

/* Android bionic and musl do not provide the GNU regex (re_*) interface that
 * busybox uses for CONFIG_EXTRA_COMPAT (grep) and CONFIG_FEATURE_VI_REGEX_SEARCH.
 * This header keeps the POSIX part from the real libc header and adds a
 * GNU-compatible facade implemented over regcomp()/regexec() in
 * libbb/missing_syscalls.c. glibc builds are unaffected. */

#if defined(__ANDROID__)
# define BB_LIBC_HAS_GNU_REGEX 0
#else
# include <features.h>
# if defined(__GLIBC__)
#  define BB_LIBC_HAS_GNU_REGEX 1
# elif defined(__UCLIBC__) || defined(__DEFINED_)
#  define BB_LIBC_HAS_GNU_REGEX 0
# else
#  define BB_LIBC_HAS_GNU_REGEX 0
# endif
#endif

#if !BB_LIBC_HAS_GNU_REGEX
/* musl / bionic define regex_t as "struct re_pattern_buffer". Rename that tag
 * so the classic GNU name can be used for our own struct below. */
# define re_pattern_buffer bb_libc_internal_re_pattern_buffer
#endif
#include_next <regex.h>
#if !BB_LIBC_HAS_GNU_REGEX
# undef re_pattern_buffer

typedef char *RE_TRANSLATE_TYPE;

struct re_pattern_buffer {
	regex_t rx;
	RE_TRANSLATE_TYPE translate;   /* non-NULL => case-insensitive (-i) */
	int compiled;
	int flags;
	int not_bol;                   /* REG_NOTBOL for the next search */
	int not_eol;                   /* REG_NOTEOL for the next search */
};

struct re_registers {
	unsigned num_regs;
	regoff_t *start;
	regoff_t *end;
};

/* syntax bits (only the ones busybox sets; this is our own encoding) */
#define RE_ICASE           0x0001
#define RE_DOT_NEWLINE     0x0002
#define RE_DOT_NOT_NULL    0x0004
#define RE_INTERVALS       0x0008
#define RE_NO_BK_BRACES    0x0010
#define RE_NO_BK_PARENS    0x0020   /* set => extended regex syntax */
#define RE_CONTEXT_INDEP_OPS 0x0040

#define RE_SYNTAX_GREP        (RE_INTERVALS)
#define RE_SYNTAX_EGREP       (RE_NO_BK_PARENS|RE_INTERVALS|RE_NO_BK_BRACES)
#define RE_SYNTAX_POSIX_BASIC (RE_INTERVALS)

extern unsigned re_syntax_options;

extern const char *re_compile_pattern(const char *pattern, size_t length,
			struct re_pattern_buffer *bufp);
extern int re_search(struct re_pattern_buffer *bufp, const char *string,
			int length, int start, int range,
			struct re_registers *regs);
#endif /* !BB_LIBC_HAS_GNU_REGEX */

#endif /* BB_COMPAT_REGEX_H */
