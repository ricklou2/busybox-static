/* bionic only exposes the System V shared-memory calls from API 26 on.
 * Android 7 (API 24) is our floor, so declare + provide them ourselves. */
#ifndef BB_SYS_SHM_COMPAT_H
#define BB_SYS_SHM_COMPAT_H
#include_next <sys/shm.h>
#if defined(__BIONIC__) && __ANDROID_API__ < 26
#include <sys/cdefs.h>
__BEGIN_DECLS
void *shmat(int shmid, const void *shmaddr, int shmflg);
int shmctl(int shmid, int cmd, struct shmid_ds *buf);
int shmdt(const void *shmaddr);
int shmget(key_t key, size_t size, int shmflg);
__END_DECLS
#endif
#endif
