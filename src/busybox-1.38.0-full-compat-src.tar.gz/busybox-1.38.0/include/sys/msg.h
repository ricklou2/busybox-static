/* bionic only exposes the System V message-queue calls from API 26 on. */
#ifndef BB_SYS_MSG_COMPAT_H
#define BB_SYS_MSG_COMPAT_H
#include_next <sys/msg.h>
#if defined(__BIONIC__) && __ANDROID_API__ < 26
#include <sys/cdefs.h>
__BEGIN_DECLS
int msgget(key_t key, int msgflg);
int msgctl(int msqid, int cmd, struct msqid_ds *buf);
ssize_t msgrcv(int msqid, void *msgp, size_t msgsz, long msgtyp, int msgflg);
int msgsnd(int msqid, const void *msgp, size_t msgsz, int msgflg);
__END_DECLS
#endif
#endif
