/* bionic only exposes the System V semaphore calls from API 26 on. */
#ifndef BB_SYS_SEM_COMPAT_H
#define BB_SYS_SEM_COMPAT_H
#include_next <sys/sem.h>
#if defined(__BIONIC__) && __ANDROID_API__ < 26
#include <sys/cdefs.h>
__BEGIN_DECLS
int semget(key_t key, int nsems, int semflg);
int semop(int semid, struct sembuf *sops, size_t nsops);
int semctl(int semid, int semnum, int cmd, ...);
__END_DECLS
#endif
#endif
