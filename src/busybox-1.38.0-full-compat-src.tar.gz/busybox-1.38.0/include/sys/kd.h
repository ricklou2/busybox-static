/*
 * Android/bionic has no <sys/kd.h> (the glibc wrapper around the Linux
 * console API). The kernel UAPI <linux/kd.h> that bionic DOES ship already
 * carries every ioctl, struct and enum the console tools need; only the
 * old-style font flag macro from glibc's wrapper is absent.
 */
#ifndef BB_COMPAT_SYS_KD_H
#define BB_COMPAT_SYS_KD_H

#include <linux/kd.h>

/* glibc <sys/kd.h>: invoke the old KDFONTOP-style font ioctl */
#ifndef KD_FONT_FLAG_OLD
# define KD_FONT_FLAG_OLD 0x80000000
#endif

#endif /* BB_COMPAT_SYS_KD_H */
