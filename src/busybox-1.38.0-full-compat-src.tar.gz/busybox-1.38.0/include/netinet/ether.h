/*
 * bionic's <netinet/ether.h> declares ether_ntoa/ether_aton but not the
 * /etc/ethers lookup helper ether_hostton() that ether-wake uses.
 */
#ifndef BB_COMPAT_NETINET_ETHER_H
#define BB_COMPAT_NETINET_ETHER_H

#include_next <netinet/ether.h>
#include <net/ethernet.h>

__BEGIN_DECLS

/* returns 0 when the hostname was found in /etc/ethers, -1 otherwise */
int ether_hostton(const char *__hostname, struct ether_addr *__addr);

__END_DECLS

#endif /* BB_COMPAT_NETINET_ETHER_H */
